
#include <iostream>
#include <vector>

#include <gtk/gtk.h>

#if defined(_WIN32) || defined(WIN32)
//    #include <gdk/gdkwin32.h>
#elif defined(__unix__) || defined(__unix) || defined(unix) || defined(__linux__) || defined(__linux) || defined(linux) || defined(__gnu_linux__)
#else
#endif

#include "Tserial_event.h"

// ========================================================================================================================

    GtkBuilder  *gbuilder;
    GError      *gerror = NULL;

    GtkWidget   *gtk_window_1;
    GtkWidget   *gtk_button_1;
    GtkWidget   *gtk_entry_1;
    GtkWidget   *gtk_label_1;
    GtkWidget   *gtk_text_view_1;

    Tserial_event *com;
    std::vector<std::string> data_in;

// ========================================================================================================================

void logtx (std::string str);

// ========================================================================================================================

/* ======================================================== */
/* ===============  OnCharArrival     ===================== */
/* ======================================================== */
void OnDataArrival(int size, char *buffer)
{
    if ((size>0) && (buffer!=0))
    {
        buffer[size] = 0;
//        logtx("OnDataArrival: " + std::string(buffer));
        gtk_label_set_text(GTK_LABEL(gtk_label_1), buffer);
        data_in.push_back(std::string(buffer));
    }
}

/* ======================================================== */
/* ===============  OnCharArrival     ===================== */
/* ======================================================== */
void SerialEventManager(void* object, uint32 event)    // BYLO: void SerialEventManager(uint32 object, uint32 event)
{
    char *buffer;
    int   size;
    Tserial_event *com;

    com = (Tserial_event *) object;
    if (com!=0)
    {
        switch(event)
        {
            case  SERIAL_CONNECTED  :
                                        logtx("Connected ! \n");
                                        break;
            case  SERIAL_DISCONNECTED  :
                                        logtx("Disonnected ! \n");
                                        break;
            case  SERIAL_DATA_SENT  :
                                        logtx("Data sent ! \n");
                                        break;
            case  SERIAL_RING       :
                                        logtx("DRING ! \n");
                                        break;
            case  SERIAL_CD_ON      :
                                        logtx("Carrier Detected ! \n");
                                        break;
            case  SERIAL_CD_OFF     :
                                        logtx("No more carrier ! \n");
                                        break;
            case  SERIAL_DATA_ARRIVAL  :
                                        size   = com->getDataInSize();
                                        buffer = com->getDataInBuffer();
                                        OnDataArrival(size, buffer);
                                        com->dataHasBeenRead();
                                        break;
        }
    }
}

// ========================================================================================================================

void logtx (std::string str) {

    GtkTextBuffer *buffer;
    GtkTextIter iter;

    buffer = gtk_text_view_get_buffer ( GTK_TEXT_VIEW(gtk_text_view_1) );

    gtk_text_buffer_get_iter_at_offset (buffer, &iter, 0);
    gtk_text_buffer_insert (buffer, &iter, std::string(str + "\n").c_str(), -1);
}

// ========================================================================================================================


extern "C" G_MODULE_EXPORT void on_window_main_destroy () {

    // zakonczenie polaczenia i skasowanie obiektu
    com->disconnect();
    delete com;
    com = 0;

    gtk_main_quit ();
}

// ========================================================================================================================

void on_gtk_button_1_clicked (GtkButton *button, gpointer user_data) {
    logtx ("len: " + std::to_string(data_in.size()));
    for (unsigned int idx = 0; idx < data_in.size(); idx++)
        logtx(data_in[idx]);
    data_in.clear();
}

// ========================================================================================================================

int main( int argc, char *argv[]) {

    gtk_init(&argc, &argv);

    // wczytamy widgety z pliku *.glade za pomoca GtkBuilder
    gbuilder = gtk_builder_new();
    if ( !gtk_builder_add_from_file(gbuilder, "pwi_serial.glade", &gerror) ) { // jesli wystapill blad
        // klasa diagnostyczna powinna zapisac do pliku: "GBuilder error: " + std::string(gerror->message)
        g_free( gerror );
        return( 1 ); // wyjscie z programu z kodem informacji o bledzie
    }

    gtk_window_1 = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "gtk_window_1" ) );
    gtk_button_1 = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "gtk_button_1" ) );
    gtk_entry_1 = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "gtk_entry_1" ) );
    gtk_label_1 = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "gtk_label_1" ) );
    gtk_text_view_1 = GTK_WIDGET ( gtk_builder_get_object( gbuilder, "gtk_text_view_1" ) );

    gtk_builder_connect_signals( gbuilder, NULL );  // w tym projekcie automatyczne podpiecie tylko on_window_main_destroy()
    g_object_unref ( G_OBJECT( gbuilder ) );     // mozna juz usunac gbuilder

    g_signal_connect ( gtk_button_1, "clicked", G_CALLBACK(on_gtk_button_1_clicked), NULL );   // reczne podpiecie funkcji do sygnalu 'clicked' dla widgetu gtk_button_1

    gtk_window_set_default_size ( GTK_WINDOW(gtk_window_1), 800, 650 );
    gtk_window_set_position ( GTK_WINDOW(gtk_window_1), GTK_WIN_POS_CENTER );
    gtk_widget_show ( gtk_window_1 );

// ========================================================================================================================

    // utworzenie obiektu Tserial_event i proba inicjacji polaczenia RS
    int error = 0;

    com = new Tserial_event();
    if (com!=0)
    {
        com->setManager(SerialEventManager);
        error = com->connect("COM5", 115200, SERIAL_PARITY_NONE, 8, true);
        if (!error)
        {
            //com->sendData("Hello World\n");
            com->setRxSize(5);
        }
        else
            logtx("ERROR : com->connect (" + std::to_string(error) + ")\n");

    }

// ========================================================================================================================

    gtk_main(); // w tej petli program okienkowy tkwi, dopuki go nie zakonczymy przyciskiem 'X'

// ========================================================================================================================

    // zakonczenie przeniesiono do on_window_main_destroy

    return 0;
}

