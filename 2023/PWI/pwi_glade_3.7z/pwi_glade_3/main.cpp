
#define _POSIX_THREAD_SAFE_FUNCTIONS // localtime_r

#include <time.h>                    // localtime_r
#include <math.h>

#define M_PI 3.14159

#include <iostream>
#include <locale>
#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include <cairo.h>
#include <vector>
#include <map>
//#include "mlog.hpp"

GtkBuilder  *gbuilder;
GtkWidget   *gtk_window;
GError      *gerror = NULL;

GdkPixbuf   *gtk_window_pixbuf;

GtkWidget   *gtk_drawing_area_1;
GtkWidget   *gtk_check_button_1_1;
GtkWidget   *gtk_check_button_1_2;
GtkWidget   *gtk_check_button_1_3;
GtkWidget   *gtk_check_button_2_1;
GtkWidget   *gtk_check_button_2_2;
GtkWidget   *gtk_check_button_2_3;
GtkWidget   *gtk_label_1;
GtkWidget   *gtk_label_2;

// ========================================================================================================================

static void do_drawing(cairo_t *);

// ========================================================================================================================

    struct _mt_timerec {
        short year;     // pelny a nie od 1900
        short month;
        short day;
        short hour;
        short minute;
        short sec;
        short msec;
        double mtime;
        time_t globsec; // w sekundach od January 1, 1970 UTC
        short timezone;
        short daylightflag;
        short dayofweek;
        short dayofyear;
        short isdst;
    };

    // zwraca rekord z elementami daty i czasu
    _mt_timerec _m_gettime(void) {
        _mt_timerec res;
        timeb timebuffer;
        ftime( &timebuffer );                  // Note: _ftime is deprecated; consider using _ftime_s instead
        res.globsec = timebuffer.time;          // Seconds since midnight, January 1, 1970 (UTC)
        res.msec = timebuffer.millitm;
        res.mtime = (double)timebuffer.time + (double)timebuffer.millitm / 1000;
        res.timezone = timebuffer.timezone;     // Minutes between UTC and local time
        res.daylightflag = timebuffer.dstflag;  // Daylight savings time flag (1 means Daylight time is in effect)
        std::tm now_tm;
        if (localtime_r(&res.globsec, &now_tm) == NULL) {   // jesli nie dziala, to brakuje #define _POSIX_THREAD_SAFE_FUNCTIONS w build options -> #defines
            res.year = 0;
            res.month = 0;
            res.day = 0;
            res.hour = 0;
            res.minute = 0;
            res.sec = 0;
            res.dayofweek = 0;
            res.dayofyear = 0;
            res.isdst = 0;
        } else {
            res.year = now_tm.tm_year + 1900;
            res.month = now_tm.tm_mon + 1;         // w oryginale 0-11
            res.day = now_tm.tm_mday;
            res.hour = now_tm.tm_hour;
            res.minute = now_tm.tm_min;
            res.sec = now_tm.tm_sec;               // w oryginale 0-61
            res.dayofweek = now_tm.tm_wday + 1;        // w oryginale od 0 - od niedzieli
            res.dayofyear = now_tm.tm_yday + 1;        // w oryginale od 0 - do 365
            res.isdst = now_tm.tm_isdst;
        }
        return res;
    }

    // zwraca string w postaci rok_miesiac_dzien_godzina_minuta_sekunda_milisekunda
    std::string _m_gettime_str() {
        _mt_timerec mtime = _m_gettime();
        return std::to_string(mtime.year) + "_" + std::to_string(mtime.month) + "_" + std::to_string(mtime.day) + "_" + std::to_string(mtime.hour) + "_" + std::to_string(mtime.minute) + "_" + std::to_string(mtime.sec) + "_" + std::to_string(mtime.msec);
    }

// ========================================================================================================================

GdkPixbuf *create_pixbuf(const gchar * filename) {
    GdkPixbuf *pixbuf;
    GError *error = NULL;
    pixbuf = gdk_pixbuf_new_from_file(filename, &error);
    if(!pixbuf) {
        //fprintf(stderr, "%s\n", error->message);
        g_error_free(error);
    }

    return pixbuf;
}

// ========================================================================================================================

static gboolean time_handler(GtkWidget *widget) {
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_check_button_2_1))) {
        gtk_widget_queue_draw(gtk_drawing_area_1);
    }
    return TRUE;
}

// ========================================================================================================================

static gboolean on_gtk_drawing_area_draw(GtkWidget *widget, cairo_t *cr, gpointer user_data) {
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_check_button_1_1))) {
        do_drawing(cr);
    }
    return FALSE;
}

// ========================================================================================================================

static void do_drawing(cairo_t *cr) {

    // text
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_check_button_1_3))) {
        cairo_set_source_rgb(cr, 0, 0, 0);
        cairo_select_font_face(cr, "Sans", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL);
        cairo_set_font_size(cr, 40.0);
        cairo_move_to(cr, 10.0, 50.0);
        cairo_show_text(cr, "ala ma kota");
        cairo_set_font_size(cr, 20.0);
        cairo_move_to(cr, 10.0, 80.0);
        cairo_show_text(cr, "ala ma kota");
        cairo_set_font_size(cr, 10.0);
        cairo_move_to(cr, 10.0, 100.0);
        cairo_show_text(cr, "ala ma kota");
    }

    // rectangle
    cairo_set_source_rgb(cr, 0, 0, 0);
    cairo_set_line_width(cr, 1);
    cairo_rectangle(cr, 5.5, 5.5, 320, 320);
    cairo_stroke(cr);

    // translation + arc + fill
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_check_button_2_2))) {
        int d_x = 256;
        int d_y = 256;
        cairo_set_line_width(cr, 9);
        cairo_set_source_rgb(cr, 0.69, 0.19, 0);
        cairo_translate(cr, d_x, d_y);
        cairo_arc(cr, 0, 0, 50, 0, 1.5 * M_PI);  // cr, xc,yx, radius, angle_start, angle_stop
        cairo_stroke_preserve(cr);                  //    cairo_stroke(cr);
        cairo_set_source_rgb(cr, 0.3, 0.4, 0.6);
        cairo_fill(cr);
        cairo_translate(cr, -d_x, -d_y);
    }

    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_check_button_1_2))) {

        cairo_surface_t *surface_new = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 320, 320);
        cairo_t *cr_new = cairo_create(surface_new);

        cairo_set_source_rgba(cr_new, 0, 0, 0, 1);
        cairo_set_line_width(cr_new, 1);
        cairo_arc(cr_new, 160, 160, 150, 0 * M_PI, 2 * M_PI);  // cr, xc,yx, radius, angle_start, angle_stop
        cairo_stroke(cr_new);

        _mt_timerec actime = _m_gettime();
        int x1,y1;
        int x2,y2;

        cairo_set_source_rgba(cr_new, 0, 0, 0, 0.5);
        cairo_set_line_width(cr_new, 1);
        for (int minu = 0 ; minu < 60; minu ++) {
            x2 = 150 *sin(M_PI - minu/60. * 2*M_PI);
            y2 = 150 *cos(M_PI - minu/60. * 2*M_PI);
            x1 = 140 *sin(M_PI - minu/60. * 2*M_PI);
            y1 = 140 *cos(M_PI - minu/60. * 2*M_PI);
            cairo_move_to(cr_new, 160+x1, 160+y1);
            cairo_line_to(cr_new, 160+x2, 160+y2);
        }
        cairo_stroke(cr_new);

        cairo_set_source_rgba(cr_new, 0, 0, 0, 1);
        cairo_set_line_width(cr_new, 2);
        for (int minu = 0 ; minu < 12; minu ++) {
            x2 = 150 *sin(M_PI - (minu * 5)/60. * 2*M_PI);
            y2 = 150 *cos(M_PI - (minu * 5)/60. * 2*M_PI);
            x1 = 130 *sin(M_PI - (minu * 5)/60. * 2*M_PI);
            y1 = 130 *cos(M_PI - (minu * 5)/60. * 2*M_PI);
            cairo_move_to(cr_new, 160+x1, 160+y1);
            cairo_line_to(cr_new, 160+x2, 160+y2);
        }
        cairo_stroke(cr_new);

        cairo_set_source_rgba(cr_new, 0, 0, 1, 1);
        cairo_set_line_width(cr_new, 5);
        x2 = 80 *sin(M_PI - ((actime.hour % 12)/12. + actime.minute/720.) * 2*M_PI);  //blad, bo pokazuje tylko calkowite godziny, prawdziwa wskazowka jest pomiedzy godzinami
        y2 = 80 *cos(M_PI - ((actime.hour % 12)/12. + actime.minute/720.) * 2*M_PI);
        cairo_move_to(cr_new, 160, 160);
        cairo_line_to(cr_new, 160+x2, 160+y2);
        cairo_stroke(cr_new);

        cairo_set_source_rgba(cr_new, 0, 1, 0, 1);
        cairo_set_line_width(cr_new, 3);
        x2 = 100 *sin(M_PI - (actime.minute/60. + actime.sec/3600.) * 2*M_PI);
        y2 = 100 *cos(M_PI - (actime.minute/60. + actime.sec/3600.) * 2*M_PI);
        cairo_move_to(cr_new, 160, 160);
        cairo_line_to(cr_new, 160+x2, 160+y2);
        cairo_stroke(cr_new);

        cairo_set_source_rgba(cr_new, 1, 0, 0, 1);
        cairo_set_line_width(cr_new, 1);
        x2 = 120 *sin(M_PI - (actime.sec/60. + actime.msec/60000.) * 2*M_PI);
        y2 = 120 *cos(M_PI - (actime.sec/60. + actime.msec/60000.) * 2*M_PI);
        cairo_move_to(cr_new, 160, 160);
        cairo_line_to(cr_new, 160+x2, 160+y2);
        cairo_stroke(cr_new);

        if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_check_button_2_3))) {

            unsigned char * data = cairo_image_surface_get_data (surface_new);
            int stride = cairo_image_surface_get_stride (surface_new);

            for (int pixy = 0; pixy < 128; pixy++)
                for (int pixx = 0; pixx < 128; pixx++) {
                    data[pixy * stride + pixx*4 + 2] = 255-data[pixy * stride + pixx*4 + 2];    // Red
                    data[pixy * stride + pixx*4 + 1] = data[pixy * stride + pixx*4 + 1] >> 1;   // Blue
                    //data[pixy * stride + pixx*4 + 3] = 255;   // Blue
                    data[pixy * stride + pixx*4 + 0] = data[pixy * stride + pixx*4 + 3] >> 1;   // Blue
                }
            for (int pixy = 128; pixy < 256; pixy++)
                for (int pixx = 0; pixx < 128; pixx++) {
                    data[pixy * stride + pixx*4 + 0] = 255-data[pixy * stride + pixx*4 + 0];    // Blue
                }
            for (int pixy = 0; pixy < 128; pixy++)
                for (int pixx = 128; pixx < 256; pixx++) {
                    data[pixy * stride + pixx*4 + 1] = 255-data[pixy * stride + pixx*4 + 1];    // Green
                }
            for (int pixy = 128; pixy < 256; pixy++)
                for (int pixx = 128; pixx < 256; pixx++) {
                    data[pixy * stride + pixx*4 + 3] = 255-data[pixy * stride + pixx*4 + 3];    // Alpha
                }
        }

        cairo_set_source_surface (cr, surface_new, 100, 25);
        cairo_destroy(cr_new);
        cairo_surface_destroy(surface_new);
        cairo_paint(cr);
    }

}

// ========================================================================================================================

static gboolean on_gtk_window_clicked(GtkWidget *widget, GdkEventButton *event, gpointer user_data) {

    if (event->button == 1) {   // Left Mouse Button
        GtkAllocation allocation;
        gtk_widget_get_allocation (gtk_drawing_area_1, &allocation);
        // wynikowe polozenie X to: event->x - allocation.x;
        // wynikowe polozenie Y to: event->y - allocation.y;
    }

    if (event->button == 3) {   // Right Mouse Button
        gtk_widget_queue_draw(widget);
    }

    return TRUE;
}

// ========================================================================================================================

static gboolean on_gtk_window_moved(GtkWidget *widget, GdkEventMotion *event, gpointer user_data) {

    if (event->is_hint) {}
    else {
        gtk_label_set_text(GTK_LABEL(gtk_label_1), (std::to_string(event->x) + "." + std::to_string(event->y) + "." + std::to_string(event->state)).c_str());

        if (event->state == GDK_BUTTON1_MASK) {  // GDK_BUTTON1_MASK = 256 - oznacza LMB
            GtkAllocation allocation;
            gtk_widget_get_allocation (gtk_drawing_area_1, &allocation);
            // wynikowe polozenie X to: event->x - allocation.x;
            // wynikowe polozenie Y to: event->y - allocation.y;
            gtk_widget_queue_draw(widget);
        }
    }

    return TRUE;
}

// ========================================================================================================================

void on_gtk_check_button_clicked(GtkWidget *widget, gpointer user_data) {
    if (widget == gtk_check_button_2_1) {
        if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_check_button_2_1))) {
        }
    }
}

// ========================================================================================================================

void on_gtk_window_main_destroy (GtkWidget* widget, gpointer gmain) {
    gdk_pixbuf_unref (gtk_window_pixbuf);
    gtk_main_quit();
}

// ========================================================================================================================

gboolean on_gtk_window_configure_event(GtkWidget *widget, GdkEvent *event, gpointer gmain) {
    char buf[30];
    sprintf(buf, "%d, %d, %d, %d", event->configure.x, event->configure.y, event->configure.width, event->configure.height);
    gtk_window_set_title(GTK_WINDOW(gtk_window),buf);
    return FALSE;
}

// ========================================================================================================================

int main( int argc, char *argv[]) {

    //MLOG_INIT

    gtk_init(&argc, &argv);

    std::string strloc = setlocale(LC_NUMERIC, "C");    //rozwiazuje problem - spowrotem na kropke

    gbuilder = gtk_builder_new();
    if ( !gtk_builder_add_from_file(gbuilder, "pwi_glade_3.glade", &gerror) ) {
        //MLOGSO("GBuilder error: " + std::string(gerror->message));
        g_free( gerror );
        return( 1 );
    }

    gtk_window = GTK_WIDGET( gtk_builder_get_object( gbuilder, "gtk_window" ) );
    gtk_drawing_area_1 = GTK_WIDGET( gtk_builder_get_object( gbuilder, "gtk_drawing_area_1" ) );
    gtk_check_button_1_1 = GTK_WIDGET( gtk_builder_get_object( gbuilder, "gtk_check_button_1_1" ) );
    gtk_check_button_1_2 = GTK_WIDGET( gtk_builder_get_object( gbuilder, "gtk_check_button_1_2" ) );
    gtk_check_button_1_3 = GTK_WIDGET( gtk_builder_get_object( gbuilder, "gtk_check_button_1_3" ) );
    gtk_check_button_2_1 = GTK_WIDGET( gtk_builder_get_object( gbuilder, "gtk_check_button_2_1" ) );
    gtk_check_button_2_2 = GTK_WIDGET( gtk_builder_get_object( gbuilder, "gtk_check_button_2_2" ) );
    gtk_check_button_2_3 = GTK_WIDGET( gtk_builder_get_object( gbuilder, "gtk_check_button_2_3" ) );
    gtk_label_1 = GTK_WIDGET( gtk_builder_get_object( gbuilder, "gtk_label_1" ) );
    gtk_label_2 = GTK_WIDGET( gtk_builder_get_object( gbuilder, "gtk_label_2" ) );

    gtk_builder_connect_signals( gbuilder, NULL );
    g_object_unref( G_OBJECT( gbuilder ) );

    g_signal_connect(gtk_window, "destroy", G_CALLBACK(on_gtk_window_main_destroy), NULL);
    g_signal_connect(gtk_window, "configure-event", G_CALLBACK(on_gtk_window_configure_event), NULL);

    gtk_window_set_default_size(GTK_WINDOW(gtk_window), 1000, 850);
    gtk_window_set_position(GTK_WINDOW(gtk_window), GTK_WIN_POS_CENTER);
    gtk_window_pixbuf = create_pixbuf("icon.png");
    gtk_window_set_icon(GTK_WINDOW(gtk_window), gtk_window_pixbuf);

    gtk_widget_add_events(gtk_window, GDK_BUTTON_PRESS_MASK);
    gtk_widget_add_events(gtk_window, GDK_POINTER_MOTION_MASK);

    g_timeout_add(125, (GSourceFunc) time_handler, (gpointer) gtk_window);

    g_signal_connect(G_OBJECT(gtk_drawing_area_1), "draw", G_CALLBACK(on_gtk_drawing_area_draw), NULL);

    g_signal_connect(gtk_window, "button-press-event", G_CALLBACK(on_gtk_window_clicked), NULL);
    g_signal_connect(gtk_window, "motion_notify_event", G_CALLBACK(on_gtk_window_moved), NULL);

    g_signal_connect(gtk_check_button_1_1, "clicked", G_CALLBACK(on_gtk_check_button_clicked), NULL);

    gtk_widget_show( gtk_window );


    gtk_main();


    return 0;
}
